export const APP_URL = {
    serviceEndPointUrl : 'http://localhost:8080/pricing',
    userMgmnt: {
       fetchUserMgmntDetails:  '/userMgmnt/details',
       saveOrUpdateUser:  '/userMgmnt/saveOrUpdate' 
    }
};
